package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Scrim
import com.example.data.model.Tournament
import com.example.ui.theme.GoldButtonGradient
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PubgCardBorder
import com.example.ui.theme.PubgInputBg
import com.example.ui.theme.PubgInputBorder
import com.example.ui.theme.RedBadge
import com.example.ui.theme.ScrimGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun AdminPanelDialog(
    scrims: List<Scrim>,
    tournaments: List<Tournament>,
    onDismiss: () -> Unit,
    onAddScrim: suspend (Scrim) -> Result<Unit>,
    onDeleteScrim: suspend (String) -> Result<Unit>,
    onAddTournament: suspend (Tournament) -> Result<Unit>,
    onDeleteTournament: suspend (String) -> Result<Unit>
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Scrims, 1: Tournaments

    // Scrim form state
    var scrimTitle by remember { mutableStateOf("") }
    var scrimDate by remember { mutableStateOf("") }
    var scrimTime by remember { mutableStateOf("") }
    var scrimMap by remember { mutableStateOf("إرانغل") }
    var scrimMaxTeams by remember { mutableStateOf("20") }
    var scrimRoomId by remember { mutableStateOf("") }
    var scrimRoomPassword by remember { mutableStateOf("") }
    var scrimRoomTime by remember { mutableStateOf("قبل الماتش بـ 15 دقيقة") }

    // Tournament form state
    var tournTitle by remember { mutableStateOf("") }
    var tournDate by remember { mutableStateOf("") }
    var tournTime by remember { mutableStateOf("") }
    var tournMap by remember { mutableStateOf("سانهوك") }
    var tournMaxTeams by remember { mutableStateOf("64") }
    var tournDesc by remember { mutableStateOf("") }

    var isSubmitting by remember { mutableStateOf(false) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color(0xFF171410),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = GoldPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "لوحة تحكم المنظم عمار",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Tabs: Scrims vs Tournaments
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = Color(0xFF201C16),
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = GoldPrimary
                            )
                        }
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0; feedbackMessage = null },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.LocalFireDepartment,
                                        contentDescription = null,
                                        tint = if (selectedTab == 0) GoldPrimary else TextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "الاسكرمات (${scrims.size})",
                                        color = if (selectedTab == 0) GoldPrimary else TextMuted,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1; feedbackMessage = null },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = if (selectedTab == 1) GoldPrimary else TextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "البطولات (${tournaments.size})",
                                        color = if (selectedTab == 1) GoldPrimary else TextMuted,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (selectedTab == 0) {
                        // SCRIM SECTION
                        Text(
                            text = "إضافة اسكرم جديد:",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        AdminTextField(value = scrimTitle, onValueChange = { scrimTitle = it }, placeholder = "عنوان الاسكرم (مثال: اسكرم الجمعة)")
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = scrimDate, onValueChange = { scrimDate = it }, placeholder = "التاريخ (مثال: الجمعة 20 نوفمبر)")
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = scrimTime, onValueChange = { scrimTime = it }, placeholder = "الوقت (مثال: 8:00 م)")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = scrimMap, onValueChange = { scrimMap = it }, placeholder = "الخريطة (إرانغل)")
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = scrimMaxTeams, onValueChange = { scrimMaxTeams = it }, placeholder = "أقصى فرق (20)", keyboardType = KeyboardType.Number)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = scrimRoomId, onValueChange = { scrimRoomId = it }, placeholder = "رقم الروم ID")
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = scrimRoomPassword, onValueChange = { scrimRoomPassword = it }, placeholder = "كلمة المرور")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        AdminTextField(value = scrimRoomTime, onValueChange = { scrimRoomTime = it }, placeholder = "وقت دخول الروم")

                        Spacer(modifier = Modifier.height(10.dp))

                        // Add Scrim Button
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(GoldButtonGradient)
                                .clickable(enabled = !isSubmitting) {
                                    if (scrimTitle.isBlank() || scrimDate.isBlank() || scrimTime.isBlank()) {
                                        feedbackMessage = "يرجى تعبئة العنوان والتاريخ والوقت"
                                        isSuccess = false
                                    } else {
                                        isSubmitting = true
                                        feedbackMessage = null
                                        coroutineScope.launch {
                                            val newScrim = Scrim(
                                                scrimId = "scrim_${UUID.randomUUID().toString().take(8)}",
                                                title = scrimTitle,
                                                date = scrimDate,
                                                time = scrimTime,
                                                map = scrimMap.ifBlank { "إرانغل" },
                                                maxTeams = scrimMaxTeams.toIntOrNull() ?: 20,
                                                registeredTeams = 0,
                                                status = "open",
                                                statusLabel = "مفتوح التسجيل",
                                                roomId = scrimRoomId,
                                                roomPassword = scrimRoomPassword,
                                                roomVisibleAt = scrimRoomTime
                                            )
                                            val res = onAddScrim(newScrim)
                                            isSubmitting = false
                                            if (res.isSuccess) {
                                                isSuccess = true
                                                feedbackMessage = "تمت إضافة الاسكرم بنجاح!"
                                                scrimTitle = ""
                                                scrimDate = ""
                                                scrimTime = ""
                                                scrimRoomId = ""
                                                scrimRoomPassword = ""
                                            } else {
                                                isSuccess = false
                                                feedbackMessage = res.exceptionOrNull()?.localizedMessage ?: "حدث خطأ"
                                            }
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إضافة الاسكرم", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Scrim list & delete
                        Text(
                            text = "قائمة الاسكرمات الحالية:",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        scrims.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF221E18))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = item.title, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(text = "${item.date} | مسجل: ${item.registeredTeams}/${item.maxTeams}", color = TextMuted, fontSize = 11.sp)
                                }
                                IconButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            onDeleteScrim(item.scrimId)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = RedBadge, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                    } else {
                        // TOURNAMENT SECTION
                        Text(
                            text = "إضافة بطولة جديدة:",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        AdminTextField(value = tournTitle, onValueChange = { tournTitle = it }, placeholder = "عنوان البطولة (مثال: بطولة عمار الكبرى)")
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = tournDate, onValueChange = { tournDate = it }, placeholder = "التاريخ (السبت 22 نوفمبر)")
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = tournTime, onValueChange = { tournTime = it }, placeholder = "الوقت (9:00 م)")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = tournMap, onValueChange = { tournMap = it }, placeholder = "الخريطة (سانهوك)")
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                AdminTextField(value = tournMaxTeams, onValueChange = { tournMaxTeams = it }, placeholder = "الفرق (64)", keyboardType = KeyboardType.Number)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        AdminTextField(value = tournDesc, onValueChange = { tournDesc = it }, placeholder = "وصف وجوائز البطولة")

                        Spacer(modifier = Modifier.height(10.dp))

                        // Add Tournament Button
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(GoldButtonGradient)
                                .clickable(enabled = !isSubmitting) {
                                    if (tournTitle.isBlank() || tournDate.isBlank() || tournTime.isBlank()) {
                                        feedbackMessage = "يرجى تعبئة العنوان والتاريخ والوقت"
                                        isSuccess = false
                                    } else {
                                        isSubmitting = true
                                        feedbackMessage = null
                                        coroutineScope.launch {
                                            val newTourn = Tournament(
                                                tournamentId = "tourn_${UUID.randomUUID().toString().take(8)}",
                                                title = tournTitle,
                                                date = tournDate,
                                                time = tournTime,
                                                map = tournMap.ifBlank { "سانهوك" },
                                                maxTeams = tournMaxTeams.toIntOrNull() ?: 64,
                                                registeredTeams = 0,
                                                status = "open",
                                                statusLabel = "قيد التسجيل",
                                                description = tournDesc.ifBlank { "بطولة برعاية عمار أبو دقه" }
                                            )
                                            val res = onAddTournament(newTourn)
                                            isSubmitting = false
                                            if (res.isSuccess) {
                                                isSuccess = true
                                                feedbackMessage = "تمت إضافة البطولة بنجاح!"
                                                tournTitle = ""
                                                tournDate = ""
                                                tournTime = ""
                                                tournDesc = ""
                                            } else {
                                                isSuccess = false
                                                feedbackMessage = res.exceptionOrNull()?.localizedMessage ?: "حدث خطأ"
                                            }
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إضافة البطولة", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Tournament list & delete
                        Text(
                            text = "قائمة البطولات الحالية:",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        tournaments.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF221E18))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = item.title, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(text = "${item.date} | مسجل: ${item.registeredTeams}/${item.maxTeams}", color = TextMuted, fontSize = 11.sp)
                                }
                                IconButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            onDeleteTournament(item.tournamentId)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = RedBadge, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    if (feedbackMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = feedbackMessage!!,
                            color = if (isSuccess) ScrimGreen else Color(0xFFFF5252),
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = onDismiss) {
                    Text("إغلاق", color = TextMuted)
                }
            }
        )
    }
}

@Composable
private fun AdminTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder, color = TextMuted, fontSize = 11.sp) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = PubgInputBg,
            unfocusedContainerColor = PubgInputBg,
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = PubgInputBorder,
            focusedTextColor = TextWhite,
            unfocusedTextColor = TextWhite
        )
    )
}
