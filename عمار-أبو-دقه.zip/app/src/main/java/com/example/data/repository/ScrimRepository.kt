package com.example.data.repository

import com.example.data.model.Scrim
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class ScrimRepository(private val db: FirebaseFirestore) {

    private val auth = Firebase.auth

    fun observeScrims(): Flow<List<Scrim>> = flow {
        val path = "scrims"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Scrim::class.java)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun seedInitialScrimsIfEmpty() = withContext(Dispatchers.IO) {
        // No-op: Do not seed default initial scrims. Admins add scrims manually.
    }

    /**
     * Atomic registration using Firestore Transaction to prevent race conditions
     * and strictly enforce team quotas.
     */
    suspend fun registerForScrim(scrimId: String, userId: String? = null): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = userId ?: auth.currentUser?.uid ?: return@withContext Result.failure(
            IllegalStateException("يجب تسجيل الدخول أولاً")
        )
        val docRef = db.collection("scrims").document(scrimId)
        try {
            db.runTransaction { transaction ->
                val snapshot = transaction.get(docRef)
                if (!snapshot.exists()) {
                    throw IllegalStateException("الاسكرم غير موجود")
                }
                val currentRegistered = snapshot.getLong("registeredTeams")?.toInt() ?: 0
                val maxTeams = snapshot.getLong("maxTeams")?.toInt() ?: 20
                @Suppress("UNCHECKED_CAST")
                val userList = (snapshot.get("registeredUserIds") as? List<String>) ?: emptyList()

                if (userList.contains(uid)) {
                    throw IllegalStateException("أنت مسجل بالفعل في هذا الاسكرم")
                }
                if (currentRegistered >= maxTeams) {
                    throw IllegalStateException("اكتمل العدد المطلوب للفرق ولا يمكن التسجيل")
                }

                val updatedList = userList + uid
                transaction.update(docRef, "registeredTeams", currentRegistered + 1)
                transaction.update(docRef, "registeredUserIds", updatedList)
                transaction.update(docRef, "updatedAt", FieldValue.serverTimestamp())
            }.await()

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    /**
     * Cancel registration using Firestore Transaction
     */
    suspend fun unregisterFromScrim(scrimId: String, userId: String? = null): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = userId ?: auth.currentUser?.uid ?: return@withContext Result.failure(
            IllegalStateException("يجب تسجيل الدخول أولاً")
        )
        val docRef = db.collection("scrims").document(scrimId)
        try {
            db.runTransaction { transaction ->
                val snapshot = transaction.get(docRef)
                if (!snapshot.exists()) {
                    throw IllegalStateException("الاسكرم غير موجود")
                }
                val currentRegistered = snapshot.getLong("registeredTeams")?.toInt() ?: 0
                @Suppress("UNCHECKED_CAST")
                val userList = (snapshot.get("registeredUserIds") as? List<String>) ?: emptyList()

                if (!userList.contains(uid)) {
                    throw IllegalStateException("أنت غير مسجل في هذا الاسكرم")
                }

                val updatedList = userList - uid
                val newCount = if (currentRegistered > 0) currentRegistered - 1 else 0
                transaction.update(docRef, "registeredTeams", newCount)
                transaction.update(docRef, "registeredUserIds", updatedList)
                transaction.update(docRef, "updatedAt", FieldValue.serverTimestamp())
            }.await()

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun addScrim(scrim: Scrim): Result<Unit> = withContext(Dispatchers.IO) {
        val docRef = db.collection("scrims").document(scrim.scrimId)
        try {
            val payload = mapOf(
                "scrimId" to scrim.scrimId,
                "title" to scrim.title,
                "date" to scrim.date,
                "dayName" to scrim.dayName,
                "dayNumber" to scrim.dayNumber,
                "monthName" to scrim.monthName,
                "time" to scrim.time,
                "map" to scrim.map,
                "maxTeams" to scrim.maxTeams,
                "registeredTeams" to 0,
                "status" to scrim.status,
                "statusLabel" to scrim.statusLabel,
                "roomId" to scrim.roomId,
                "roomPassword" to scrim.roomPassword,
                "roomVisibleAt" to scrim.roomVisibleAt,
                "registeredUserIds" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateScrim(scrim: Scrim): Result<Unit> = withContext(Dispatchers.IO) {
        val docRef = db.collection("scrims").document(scrim.scrimId)
        try {
            val updates = mutableMapOf<String, Any>(
                "title" to scrim.title,
                "date" to scrim.date,
                "time" to scrim.time,
                "map" to scrim.map,
                "maxTeams" to scrim.maxTeams,
                "status" to scrim.status,
                "statusLabel" to scrim.statusLabel,
                "roomId" to scrim.roomId,
                "roomPassword" to scrim.roomPassword,
                "roomVisibleAt" to scrim.roomVisibleAt,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteScrim(scrimId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val docRef = db.collection("scrims").document(scrimId)
        try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }
}
