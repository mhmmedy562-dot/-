package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val inGameName: String = "",
    val inGameId: String = "",
    val fullName: String = "",
    val username: String = "",
    val phone: String? = null,
    val email: String = "",
    val photoURL: String? = null,
    val provider: String = "google",
    val accountStatus: String = "active",
    val role: String = "player", // "player" or "admin"
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val lastLoginAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
