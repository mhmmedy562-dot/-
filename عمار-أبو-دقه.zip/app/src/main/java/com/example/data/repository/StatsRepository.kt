package com.example.data.repository

import com.example.data.model.GlobalStats
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class StatsRepository(private val db: FirebaseFirestore) {

    fun observeStats(): Flow<GlobalStats> = flow {
        val path = "stats/global"
        try {
            val doc = db.document(path).get().await()
            if (doc.exists()) {
                val stats = doc.toObject(GlobalStats::class.java) ?: GlobalStats()
                emit(stats)
            } else {
                emit(GlobalStats(12, 8500, 25))
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            handleFirestoreError(e, OperationType.GET, path)
            emit(GlobalStats(12, 8500, 25))
        }
    }
}
