package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Tournament(
    @DocumentId val id: String = "",
    val tournamentId: String = "",
    val title: String = "",
    val date: String = "",
    val dayName: String = "",
    val dayNumber: Int = 0,
    val monthName: String = "",
    val time: String = "",
    val map: String = "",
    val maxTeams: Int = 64,
    val registeredTeams: Int = 0,
    val status: String = "open",
    val statusLabel: String = "قيد التسجيل",
    val imageURL: String = "",
    val description: String = "",
    val registeredUserIds: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
