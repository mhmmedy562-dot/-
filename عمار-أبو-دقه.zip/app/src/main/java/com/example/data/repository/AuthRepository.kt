package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.example.BuildConfig
import com.example.R
import com.example.data.model.UserProfile
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID

class AuthRepository(
    private val context: Context,
    private val firestore: FirebaseFirestore
) {
    private val auth: FirebaseAuth = Firebase.auth
    private val credentialManager = CredentialManager.create(context)
    private val prefs: SharedPreferences = context.getSharedPreferences("ammar_auth_prefs", Context.MODE_PRIVATE)

    private val _currentSession = MutableStateFlow<UserProfile?>(null)
    val currentSession: StateFlow<UserProfile?> = _currentSession.asStateFlow()

    init {
        // Restore initial session from local storage or Firebase Auth
        val savedJson = prefs.getString("active_session_profile", null)
        if (!savedJson.isNullOrBlank()) {
            try {
                val json = JSONObject(savedJson)
                _currentSession.value = UserProfile(
                    userId = json.optString("userId", UUID.randomUUID().toString()),
                    fullName = json.optString("fullName", "لاعب ببجي"),
                    username = json.optString("username", "player"),
                    inGameName = json.optString("inGameName", "لاعب ببجي"),
                    inGameId = json.optString("inGameId", "1234567890"),
                    email = json.optString("email", ""),
                    role = json.optString("role", "player"),
                    photoURL = json.optString("photoURL", null),
                    provider = json.optString("provider", "email")
                )
            } catch (e: Exception) {
                Log.w("Auth", "Failed to parse saved session profile", e)
            }
        }

        // Keep session synchronized with Firebase Auth
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                val existing = _currentSession.value
                val isAdmin = user.email.equals(BuildConfig.ADMIN_EMAIL, ignoreCase = true)
                val profile = UserProfile(
                    userId = user.uid,
                    fullName = user.displayName ?: existing?.fullName ?: "لاعب ببجي",
                    username = user.email?.substringBefore("@") ?: existing?.username ?: "player",
                    inGameName = existing?.inGameName?.ifBlank { user.displayName } ?: "لاعب ببجي",
                    inGameId = existing?.inGameId?.ifBlank { user.uid.filter { it.isDigit() }.take(10).padEnd(10, '0') } ?: "1234567890",
                    email = user.email ?: existing?.email ?: "",
                    role = if (isAdmin) "admin" else (existing?.role ?: "player"),
                    photoURL = user.photoUrl?.toString() ?: existing?.photoURL,
                    provider = if (user.providerData.any { it.providerId == "google.com" }) "google" else "email"
                )
                saveSessionLocally(profile)
            } else {
                // If Firebase Auth says no user, but we have a local "authenticated" session, clear it
                val existing = _currentSession.value
                if (existing != null && (existing.provider == "google" || existing.provider == "email")) {
                    Log.d("Auth", "Clearing stale local session because Firebase user is null")
                    _currentSession.value = null
                    prefs.edit().remove("active_session_profile").apply()
                }
            }
        }
    }

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    fun observeAuthState(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    fun observeCurrentSession(): StateFlow<UserProfile?> = currentSession

    private fun saveSessionLocally(profile: UserProfile) {
        _currentSession.value = profile
        try {
            val json = JSONObject().apply {
                put("userId", profile.userId)
                put("fullName", profile.fullName)
                put("username", profile.username)
                put("inGameName", profile.inGameName)
                put("inGameId", profile.inGameId)
                put("email", profile.email)
                put("role", profile.role)
                put("photoURL", profile.photoURL ?: "")
                put("provider", profile.provider)
            }
            prefs.edit().putString("active_session_profile", json.toString()).apply()
        } catch (e: Exception) {
            Log.w("Auth", "Failed to save session locally", e)
        }
    }

    suspend fun signInWithEmail(email: String, pass: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()
        val isAdminEmail = trimmedEmail == BuildConfig.ADMIN_EMAIL

        try {
            // 1. Attempt Real Firebase Authentication
            auth.signInWithEmailAndPassword(trimmedEmail, pass).await()
        } catch (e: Exception) {
            // 2. Special handling for Admin account if not yet in Firebase Auth
            if (isAdminEmail && pass == BuildConfig.ADMIN_PASS) {
                try {
                    auth.createUserWithEmailAndPassword(trimmedEmail, pass).await()
                } catch (createEx: Exception) {
                    // If creation fails (e.g. already exists but password mismatch handled by signIn above)
                    // we log and continue to check local registry if applicable
                }
            } else {
                // For regular users, if Auth fails, they must register properly
                return@withContext Result.failure(e)
            }
        }

        val currentUser = auth.currentUser
        val uid = currentUser?.uid ?: "admin_ammar_organizer"

        // Check if account is in local accounts registry for additional metadata
        val accountsJson = prefs.getString("registered_accounts", "{}") ?: "{}"
        val accountsObj = try { JSONObject(accountsJson) } catch (e: Exception) { JSONObject() }

        if (isAdminEmail) {
            // Organizer profile
            val adminProfile = UserProfile(
                userId = uid,
                fullName = "عمار أبو دقه",
                username = "ammar_organizer",
                inGameName = "عمار أبو دقه",
                inGameId = "1234567890",
                email = trimmedEmail,
                role = "admin",
                provider = "email"
            )
            saveSessionLocally(adminProfile)
            try { saveUserProfile(adminProfile) } catch (ignored: Exception) {}
            return@withContext Result.success(adminProfile)
        }

        if (!accountsObj.has(trimmedEmail)) {
            // Even if Auth succeeded (somehow), if we don't have local metadata, we might need a fallback profile
            val profile = UserProfile(
                userId = uid,
                fullName = trimmedEmail.substringBefore("@"),
                username = uid.take(8),
                inGameName = trimmedEmail.substringBefore("@"),
                inGameId = "0000000000",
                email = trimmedEmail,
                role = "player",
                provider = "email"
            )
            saveSessionLocally(profile)
            return@withContext Result.success(profile)
        }

        val accountData = accountsObj.getJSONObject(trimmedEmail)
        val profile = UserProfile(
            userId = uid,
            fullName = accountData.optString("inGameName", "لاعب ببجي"),
            username = accountData.optString("inGameId", "player"),
            inGameName = accountData.optString("inGameName", "لاعب ببجي"),
            inGameId = accountData.optString("inGameId", "1234567890"),
            email = trimmedEmail,
            role = accountData.optString("role", "player"),
            provider = "email"
        )
        saveSessionLocally(profile)
        Result.success(profile)
    }

    private val emailOtpService = com.example.data.service.EmailOtpService()

    suspend fun sendRegistrationOtp(email: String): Result<String> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()
        if (trimmedEmail.isBlank() || !trimmedEmail.contains("@")) {
            return@withContext Result.failure(IllegalStateException("يرجى إدخال بريد إلكتروني صحيح"))
        }
        try {
            val code = emailOtpService.generateAndSendOtp(trimmedEmail)
            Result.success(code)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registerWithEmail(
        email: String,
        pass: String,
        gameName: String = "",
        gameId: String = ""
    ): Result<UserProfile> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()

        try {
            // 1. Create Real Firebase Auth Account
            auth.createUserWithEmailAndPassword(trimmedEmail, pass).await()
        } catch (e: Exception) {
            // If already exists in Auth, try to sign in
            try {
                auth.signInWithEmailAndPassword(trimmedEmail, pass).await()
            } catch (signInEx: Exception) {
                return@withContext Result.failure(e)
            }
        }

        val currentUser = auth.currentUser
        val uid = currentUser?.uid ?: return@withContext Result.failure(IllegalStateException("فشل إنشاء معرف المستخدم"))

        val defaultName = trimmedEmail.substringBefore("@").ifBlank { "مستخدم" }
        val trimmedGameName = gameName.trim().ifBlank { defaultName }
        val generatedDigits = (1000000000L..9999999999L).random().toString()
        val trimmedGameId = if (gameId.trim().length == 10 && gameId.trim().all { it.isDigit() }) gameId.trim() else generatedDigits

        val accountsJson = prefs.getString("registered_accounts", "{}") ?: "{}"
        val accountsObj = try { JSONObject(accountsJson) } catch (e: Exception) { JSONObject() }

        val isAdmin = trimmedEmail == BuildConfig.ADMIN_EMAIL

        val accountEntry = JSONObject().apply {
            put("userId", uid)
            put("inGameName", trimmedGameName)
            put("inGameId", trimmedGameId)
            put("email", trimmedEmail)
            put("password", pass)
            put("role", if (isAdmin) "admin" else "player")
        }
        accountsObj.put(trimmedEmail, accountEntry)
        prefs.edit().putString("registered_accounts", accountsObj.toString()).apply()

        val newProfile = UserProfile(
            userId = uid,
            fullName = trimmedGameName,
            username = trimmedGameId,
            inGameName = trimmedGameName,
            inGameId = trimmedGameId,
            email = trimmedEmail,
            role = if (isAdmin) "admin" else "player",
            provider = "email"
        )

        saveSessionLocally(newProfile)

        // Asynchronously persist to Firestore if possible
        try {
            if (auth.currentUser != null) {
                saveUserProfile(newProfile)
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            // Keep local profile valid
        }

        Result.success(newProfile)
    }

    suspend fun getUserProfile(uid: String): UserProfile? = withContext(Dispatchers.IO) {
        val active = _currentSession.value
        if (active != null && active.userId == uid) {
            return@withContext active
        }

        val docRef = firestore.collection("users").document(uid)
        try {
            val snapshot = docRef.get().await()
            if (snapshot.exists()) {
                val profile = snapshot.toObject(UserProfile::class.java)
                if (profile != null) {
                    _currentSession.value = profile
                }
                profile
            } else {
                active
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            active
        }
    }

    suspend fun saveUserProfile(profile: UserProfile): Result<Unit> = withContext(Dispatchers.IO) {
        val currentUser = auth.currentUser
        val uid = currentUser?.uid ?: profile.userId.ifBlank {
            return@withContext Result.failure(IllegalStateException("معرف المستخدم غير متاح"))
        }

        if (currentUser == null) {
            saveSessionLocally(profile)
            return@withContext Result.success(Unit)
        }

        val docRef = firestore.collection("users").document(uid)
        try {
            val gameName = profile.inGameName.ifBlank { profile.fullName.ifBlank { "لاعب ببجي" } }
            val gameId = profile.inGameId.ifBlank { profile.username.ifBlank { uid.take(8) } }
            val payload = mutableMapOf<String, Any?>(
                "userId" to uid,
                "inGameName" to gameName,
                "inGameId" to gameId,
                "fullName" to gameName,
                "username" to gameId,
                "email" to (profile.email.ifBlank { auth.currentUser?.email ?: "player@ammarscrims.com" }),
                "accountStatus" to "active",
                "role" to if (profile.email == BuildConfig.ADMIN_EMAIL || auth.currentUser?.email == BuildConfig.ADMIN_EMAIL) "admin" else "player",
                "createdAt" to FieldValue.serverTimestamp(),
                "lastLoginAt" to FieldValue.serverTimestamp()
            )
            if (!profile.photoURL.isNullOrBlank()) payload["photoURL"] = profile.photoURL

            docRef.set(payload).await()
            saveSessionLocally(profile)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateGooglePlayerProfile(gameName: String, gameId: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        val current = _currentSession.value ?: return@withContext Result.failure(IllegalStateException("لا يوجد جلسة نشطة"))
        val trimmedName = gameName.trim()
        val trimmedId = gameId.trim()

        if (trimmedId.length != 10 || !trimmedId.all { it.isDigit() }) {
            return@withContext Result.failure(IllegalStateException("آيدي اللاعب يجب أن يتكون من 10 أرقام فقط"))
        }

        val updatedProfile = current.copy(
            inGameName = trimmedName.ifBlank { "لاعب ببجي" },
            inGameId = trimmedId,
            fullName = trimmedName.ifBlank { "لاعب ببجي" },
            username = trimmedId
        )

        saveSessionLocally(updatedProfile)
        try {
            saveUserProfile(updatedProfile)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
        } catch (ignored: Exception) {}

        Result.success(updatedProfile)
    }

    fun onGoogleSignInClicked(
        activity: Activity,
        scope: CoroutineScope,
        onSuccess: (UserProfile) -> Unit,
        onError: (String) -> Unit,
        onCancelled: () -> Unit
    ) {
        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            onError("إعدادات Google غير مكتملة")
            return
        }

        val googleIdOption = GetSignInWithGoogleOption.Builder(clientId)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        scope.launch {
            try {
                val result = credentialManager.getCredential(activity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    val authResult = auth.signInWithCredential(authCredential).await()
                    val user = authResult.user
                    if (user != null) {
                        val realEmail = user.email ?: ""
                        val isAdmin = realEmail.equals(BuildConfig.ADMIN_EMAIL, ignoreCase = true)
                        val realName = user.displayName?.ifBlank { null }
                            ?: realEmail.substringBefore("@")
                        val existingProfile = getUserProfile(user.uid)
                        val finalProfile = existingProfile ?: UserProfile(
                            userId = user.uid,
                            fullName = realName,
                            username = realEmail.substringBefore("@").ifBlank { "User" },
                            inGameName = realName,
                            inGameId = user.uid.filter { it.isDigit() }.take(10).padEnd(10, '0'),
                            email = realEmail,
                            photoURL = user.photoUrl?.toString(),
                            provider = "google",
                            role = if (isAdmin) "admin" else "player"
                        )
                        if (existingProfile == null) {
                            try { saveUserProfile(finalProfile) } catch (ignored: Exception) {}
                        }
                        saveSessionLocally(finalProfile)
                        onSuccess(finalProfile)
                    } else {
                        onError("فشل جلب بيانات المستخدم من Google")
                    }
                } else {
                    onError("نوع الاعتماد غير متوافق مع حسابات Google")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w("Auth", "Google Sign-In cancelled: ${e.message}")
                onCancelled()
            } catch (e: NoCredentialException) {
                Log.w("Auth", "No Google accounts available: ${e.message}")
                onError("لا يوجد حساب Google مسجل على هذا الجهاز، يرجى إضافة حساب Google من إعدادات الجهاز")
            } catch (e: Exception) {
                Log.e("Auth", "Google Sign-In error: ${e.message}", e)
                val msg = when {
                    e.message?.contains("16:") == true -> "تم إلغاء تسجيل الدخول أو إغلاق نافذة الاختيار"
                    e.message?.contains("10:") == true -> "خطأ في تكوين SHA-1 أو Client ID الخاص بـ Google"
                    e.message?.contains("Network") == true -> "يرجى التحقق من اتصال الإنترنت والمحاولة ثانية"
                    else -> e.localizedMessage ?: "حدث خطأ أثناء تسجيل الدخول بحساب Google"
                }
                onError(msg)
            }
        }
    }

    fun signOut(
        scope: CoroutineScope,
        onComplete: () -> Unit
    ) {
        scope.launch {
            withContext(NonCancellable) {
                try {
                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                } catch (e: Exception) {
                    Log.w("Auth", "Failed to clear credential state: ${e.message}")
                } finally {
                    prefs.edit().remove("active_session_profile").apply()
                    _currentSession.value = null
                    auth.signOut()
                    onComplete()
                }
            }
        }
    }
}
