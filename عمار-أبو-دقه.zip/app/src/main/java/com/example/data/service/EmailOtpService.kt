package com.example.data.service

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

data class OtpEntry(
    val code: String,
    val expiresAtMillis: Long
)

class EmailOtpService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val functions = FirebaseFunctions.getInstance()
    private val auth = Firebase.auth

    // Local in-memory active OTP map for fallback
    private val activeOtps = ConcurrentHashMap<String, OtpEntry>()

    suspend fun generateAndSendOtp(email: String): String = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()

        // 1. First attempt calling Firebase Cloud Functions backend `sendEmailOtp`
        try {
            val data = mapOf("email" to trimmedEmail)
            val result = functions
                .getHttpsCallable("sendEmailOtp")
                .call(data)
                .await()

            Log.d("EmailOtpService", "Cloud Function sendEmailOtp success: ${result.data}")
            return@withContext "SENT_VIA_CLOUD_FUNCTION"
        } catch (e: Exception) {
            Log.w("EmailOtpService", "Cloud Function sendEmailOtp failed or not deployed, using direct mailer fallback", e)
        }

        // 2. Fallback direct mail dispatch via FormSubmit AJAX endpoint
        val otpCode = (100000..999999).random().toString()
        val expiresAt = System.currentTimeMillis() + 10 * 60 * 1000L // 10 minutes expiry
        activeOtps[trimmedEmail] = OtpEntry(code = otpCode, expiresAtMillis = expiresAt)

        try {
            val requestBody = FormBody.Builder()
                .add("_subject", "رمز التحقق الخاصة بحسابك - 3Mar Abo d8a")
                .add("email", trimmedEmail)
                .add("message", "مرحباً بك في تطبيق اسكرمات وبطولات 3Mar Abo d8a.\n\nرمز التحقق الخاص بك هو: $otpCode\n\nصالح لمدة 10 دقائق. يرجى عدم مشاركته مع أي شخص.")
                .add("_captcha", "false")
                .add("_template", "box")
                .build()

            val request = Request.Builder()
                .url("https://formsubmit.co/ajax/$trimmedEmail")
                .post(requestBody)
                .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                .header("Accept", "application/json")
                .build()

            client.newCall(request).execute().use { response ->
                Log.d("EmailOtpService", "Direct mailer response code: ${response.code}")
            }
        } catch (e: Exception) {
            Log.w("EmailOtpService", "Direct mailer error", e)
        }

        try {
            auth.currentUser?.sendEmailVerification()
        } catch (_: Exception) {}

        otpCode
    }

    suspend fun verifyOtp(email: String, inputOtp: String): Boolean = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim().lowercase()
        val trimmedOtp = inputOtp.trim()

        // 1. Try Firebase Cloud Functions verifyEmailOtp
        try {
            val data = mapOf(
                "email" to trimmedEmail,
                "otpCode" to trimmedOtp
            )
            val result = functions
                .getHttpsCallable("verifyEmailOtp")
                .call(data)
                .await()

            @Suppress("UNCHECKED_CAST")
            val resMap = result.data as? Map<String, Any>
            val isVerified = resMap?.get("verified") == true
            if (isVerified) return@withContext true
        } catch (e: FirebaseFunctionsException) {
            Log.w("EmailOtpService", "Cloud Function verifyEmailOtp error: ${e.message}")
            if (e.code == FirebaseFunctionsException.Code.INVALID_ARGUMENT ||
                e.code == FirebaseFunctionsException.Code.NOT_FOUND ||
                e.code == FirebaseFunctionsException.Code.DEADLINE_EXCEEDED ||
                e.code == FirebaseFunctionsException.Code.PERMISSION_DENIED) {
                throw IllegalStateException(e.message ?: "رمز التحقق غير صحيح، يرجى إعادة التأكد")
            }
        } catch (e: Exception) {
            Log.w("EmailOtpService", "Cloud Function verifyEmailOtp call failed, using local verify fallback", e)
        }

        // 2. Local active OTP entry check
        val entry = activeOtps[trimmedEmail] ?: return@withContext false

        if (System.currentTimeMillis() > entry.expiresAtMillis) {
            activeOtps.remove(trimmedEmail)
            return@withContext false
        }

        val isValid = entry.code == trimmedOtp
        if (isValid) {
            activeOtps.remove(trimmedEmail)
        }
        isValid
    }
}
