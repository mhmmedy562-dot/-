package com.example.data.repository

import com.example.data.model.AppNotification
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class NotificationRepository(private val db: FirebaseFirestore) {

    private val auth = Firebase.auth

    fun observeUserNotifications(): Flow<List<AppNotification>> = flow {
        val uid = auth.currentUser?.uid ?: return@flow
        val path = "notifications"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot -> snapshot.toObjects(AppNotification::class.java) }
                .catch { error ->
                    if (error is CancellationException) throw error
                    handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun seedInitialNotificationsIfEmpty() = withContext(Dispatchers.IO) {
        val uid = auth.currentUser?.uid ?: return@withContext
        val path = "notifications"
        try {
            val snapshot = db.collection(path).whereEqualTo("userId", uid).limit(1).get().await()
            if (snapshot.isEmpty) {
                val sampleNotifications = listOf(
                    AppNotification(
                        notificationId = "notif_1_${uid.take(5)}",
                        userId = uid,
                        title = "مرحباً بك في تطبيق عمار أبو دقه!",
                        message = "تم تفعيل حسابك بنجاح. يمكنك الآن الانضمام للاسكرمات والبطولات الأسبوعية.",
                        isRead = false
                    ),
                    AppNotification(
                        notificationId = "notif_2_${uid.take(5)}",
                        userId = uid,
                        title = "تذكير باسكرم الجمعة",
                        message = "سيبدأ اسكرم الجمعة الأسبوعي في تمام الساعة 8:00 مساءً. جهز فريقك!",
                        isRead = false
                    ),
                    AppNotification(
                        notificationId = "notif_3_${uid.take(5)}",
                        userId = uid,
                        title = "بطولة عمار الكبرى",
                        message = "التسجيل مفتوح الآن في بطولة عمار الكبرى بجوائز مالية قيمة.",
                        isRead = false
                    )
                )
                sampleNotifications.forEach { notif ->
                    db.collection(path).document(notif.notificationId).set(
                        mapOf(
                            "notificationId" to notif.notificationId,
                            "userId" to notif.userId,
                            "title" to notif.title,
                            "message" to notif.message,
                            "isRead" to notif.isRead,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            handleFirestoreError(e, OperationType.WRITE, path)
        }
    }

    suspend fun markAsRead(notificationId: String) = withContext(Dispatchers.IO) {
        val path = "notifications/$notificationId"
        try {
            db.collection("notifications").document(notificationId).update("isRead", true).await()
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            handleFirestoreError(e, OperationType.UPDATE, path)
        }
    }
}
