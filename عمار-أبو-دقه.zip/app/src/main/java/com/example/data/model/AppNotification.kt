package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class AppNotification(
    @DocumentId val id: String = "",
    val notificationId: String = "",
    val userId: String = "",
    val title: String = "",
    val message: String = "",
    val isRead: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class GlobalStats(
    val upcomingTournamentsCount: Int = 12,
    val registeredPlayersCount: Int = 8500,
    val monthlyScrimsCount: Int = 25
)
