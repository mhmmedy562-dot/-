package com.example.data.repository

import com.example.BuildConfig
import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Tournament
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TournamentRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun observeTournaments_authenticatedUser_emitsTournaments() = runBlocking {
        signInTestUser("test_admin@emulator.internal")
        val adminRepo = TournamentRepository(firestore)
        adminRepo.addTournament(
            Tournament(
                tournamentId = "test_tourn_observe",
                title = "بطولة تجريبية للملاحظة",
                date = "السبت 15 نوفمبر",
                time = "الساعة 9:00 مساءً",
                map = "سانهوك",
                maxTeams = 64,
                registeredTeams = 0,
                status = "open",
                description = "وصف تجريبي"
            )
        )

        signInTestUser("player1@test.com")
        val repository = TournamentRepository(firestore)
        val tournaments = withTimeout(5000L) {
            repository.observeTournaments().first { it.isNotEmpty() }
        }
        assertTrue(tournaments.isNotEmpty())
        assertNotNull(tournaments.first().title)
    }

    @Test
    fun registerAndUnregisterTournament_atomicTransactions_succeed() = runBlocking {
        signInTestUser("test_admin@emulator.internal")
        val adminRepo = TournamentRepository(firestore)
        val testTournId = "test_tourn_reg_${System.currentTimeMillis()}"
        adminRepo.addTournament(
            Tournament(
                tournamentId = testTournId,
                title = "بطولة تجريبية للتسجيل",
                date = "السبت 15 نوفمبر",
                time = "الساعة 9:00 مساءً",
                map = "سانهوك",
                maxTeams = 64,
                registeredTeams = 0,
                status = "open",
                description = "وصف تجريبي"
            )
        )

        val uniqueEmail = "player_tournament_${System.currentTimeMillis()}@test.com"
        signInTestUser(uniqueEmail)
        val playerRepo = TournamentRepository(firestore)

        // 1. Register
        val regResult = withTimeout(5000L) {
            playerRepo.registerForTournament(testTournId)
        }
        assertTrue("Registration must succeed", regResult.isSuccess)

        // 2. Unregister
        val unregResult = withTimeout(5000L) {
            playerRepo.unregisterFromTournament(testTournId)
        }
        assertTrue("Unregistration must succeed", unregResult.isSuccess)
    }
}
