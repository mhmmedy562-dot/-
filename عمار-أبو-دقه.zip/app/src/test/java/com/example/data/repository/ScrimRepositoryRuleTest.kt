package com.example.data.repository

import com.example.BuildConfig
import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Scrim
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScrimRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun observeScrims_authenticatedUser_emitsScrims() = runBlocking {
        signInTestUser("test_admin@emulator.internal")
        val adminRepo = ScrimRepository(firestore)
        adminRepo.addScrim(
            Scrim(
                scrimId = "test_scrim_observe",
                title = "اسكرم تجريبي للملاحظة",
                date = "الجمعة 14 نوفمبر",
                time = "الساعة 8:00 مساءً",
                map = "إرانغل",
                maxTeams = 20,
                registeredTeams = 0,
                status = "open"
            )
        )

        signInTestUser("player1@test.com")
        val repository = ScrimRepository(firestore)
        val scrims = withTimeout(5000L) {
            repository.observeScrims().first { it.isNotEmpty() }
        }
        assertTrue(scrims.isNotEmpty())
        assertNotNull(scrims.first().title)
    }

    @Test
    fun registerForScrim_authenticatedUser_succeeds() = runBlocking {
        signInTestUser("test_admin@emulator.internal")
        val adminRepo = ScrimRepository(firestore)
        val testScrimId = "test_scrim_reg_${System.currentTimeMillis()}"
        val addRes = adminRepo.addScrim(
            Scrim(
                scrimId = testScrimId,
                title = "اسكرم تجريبي للتسجيل",
                date = "الجمعة 14 نوفمبر",
                time = "الساعة 8:00 مساءً",
                map = "إرانغل",
                maxTeams = 20,
                registeredTeams = 0,
                status = "open"
            )
        )
        if (addRes.isFailure) {
            System.err.println("Admin addScrim failed: ${addRes.exceptionOrNull()?.message}")
        }
        assertTrue("Admin must be able to add scrim", addRes.isSuccess)

        val uniqueEmail = "player_${System.currentTimeMillis()}@test.com"
        signInTestUser(uniqueEmail)
        val playerRepo = ScrimRepository(firestore)

        val result = withTimeout(5000L) {
            playerRepo.registerForScrim(testScrimId)
        }
        if (result.isFailure) {
            System.err.println("registerForScrim failed: " + result.exceptionOrNull()?.message)
            result.exceptionOrNull()?.printStackTrace()
        }
        assertTrue(result.isSuccess)

        // Test unregister
        val unregResult = withTimeout(5000L) {
            playerRepo.unregisterFromScrim(testScrimId)
        }
        assertTrue("Unregistration from scrim must succeed", unregResult.isSuccess)
    }
}

