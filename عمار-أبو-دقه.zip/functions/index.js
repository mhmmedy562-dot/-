const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const nodemailer = require("nodemailer");
const crypto = require("crypto");

admin.initializeApp();
const db = admin.firestore();

// Firebase Secret Manager for Gmail App Password
const gmailAppPassword = defineSecret("GMAIL_APP_PASSWORD");

function hashEmail(email) {
  return crypto.createHash("sha256").update(email.trim().toLowerCase()).digest("hex");
}

function hashOtp(otpCode) {
  return crypto.createHash("sha256").update(otpCode.trim()).digest("hex");
}

/**
 * Callable Function: Send 6-Digit Email OTP via Gmail SMTP
 */
exports.sendEmailOtp = onCall(
  { secrets: [gmailAppPassword] },
  async (request) => {
    const email = request.data?.email;
    if (!email || typeof email !== "string" || !email.includes("@")) {
      throw new HttpsError("invalid-argument", "يرجى كتابة بريد إلكتروني صحيح");
    }

    const cleanEmail = email.trim().lowercase();
    const emailHash = hashEmail(cleanEmail);
    const now = Date.now();

    // 1. Rate limiting check (minimum 60 seconds between resend calls)
    const otpRef = db.collection("otp_codes").doc(emailHash);
    const docSnapshot = await otpRef.get();

    if (docSnapshot.exists) {
      const data = docSnapshot.data();
      if (data.lastSentAt && now - data.lastSentAt < 60000) {
        const remainingSec = Math.ceil((60000 - (now - data.lastSentAt)) / 1000);
        throw new HttpsError(
          "resource-exhausted",
          `يرجى الانتظار ${remainingSec} ثانية قبل طلب رمز جديد`
        );
      }
    }

    // 2. Generate secure 6-digit OTP code
    const rawOtp = crypto.randomInt(100000, 1000000).toString();
    const hashedCode = hashOtp(rawOtp);
    const expiresAt = now + 10 * 60 * 1000; // 10 minutes expiry

    // Save hashed code securely in Firestore (NEVER plaintext)
    await otpRef.set({
      email: cleanEmail,
      codeHash: hashedCode,
      createdAt: admin.firestore.Timestamp.fromMillis(now),
      lastSentAt: now,
      expiresAt: admin.firestore.Timestamp.fromMillis(expiresAt),
      attempts: 0,
      used: false
    });

    // 3. Configure Nodemailer with Gmail SMTP
    const pass = gmailAppPassword.value();
    if (!pass) {
      throw new HttpsError("internal", "كلمة مرور التطبيق الخاصة بـ Gmail غير مهيأة في Firebase Secrets");
    }

    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      auth: {
        user: "hbhbhbvhhvb@gmail.com",
        pass: pass
      }
    });

    const htmlTemplate = `
      <div style="font-family: Arial, sans-serif; background-color: #0f0d0a; color: #ffffff; padding: 24px; direction: rtl; text-align: right; border-radius: 12px; max-width: 500px; margin: auto; border: 2px solid #E6A100;">
        <h2 style="color: #FFB800; text-align: center; margin-bottom: 20px;">3Mar Abo d8a | PUBG MOBILE</h2>
        <p style="font-size: 16px; color: #e0e0e0;">أهلاً بك،</p>
        <p style="font-size: 15px; color: #cccccc;">رمز التحقق الخاص بك لتأكيد الحساب هو:</p>
        <div style="text-align: center; margin: 24px 0;">
          <span style="font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #0f0d0a; background: linear-gradient(135deg, #FFD700, #FFA500); padding: 12px 28px; border-radius: 10px; display: inline-block;">${rawOtp}</span>
        </div>
        <p style="font-size: 13px; color: #aaaaaa; text-align: center;">هذا الرمز صالح لمدة 10 دقائق فقط ويُستخدم مرة واحدة.</p>
        <hr style="border: none; border-top: 1px solid #332B1E; margin: 20px 0;" />
        <p style="font-size: 11px; color: #777777; text-align: center;">جميع الحقوق محفوظة © عمار أبو دقه - PUBG MOBILE SCRIMS & TOURNAMENTS</p>
      </div>
    `;

    try {
      await transporter.sendMail({
        from: '"3Mar Abo d8a" <hbhbhbvhhvb@gmail.com>',
        to: cleanEmail,
        subject: "رمز التحقق الخاصة بحسابك - 3Mar Abo d8a",
        html: htmlTemplate
      });

      return {
        success: true,
        message: "تم إرسال رمز التحقق إلى حساب الجميل الخاص بك بنجاح"
      };
    } catch (err) {
      console.error("Nodemailer Gmail dispatch error:", err);
      throw new HttpsError("internal", "فشل إرسال البريد الإلكتروني عبر Gmail، يرجى التأكد من صحة البريد والمحاولة لاحقاً");
    }
  }
);

/**
 * Callable Function: Verify 6-Digit Email OTP
 */
exports.verifyEmailOtp = onCall(async (request) => {
  const email = request.data?.email;
  const otpCode = request.data?.otpCode;

  if (!email || !otpCode || typeof otpCode !== "string" || otpCode.trim().length !== 6) {
    throw new HttpsError("invalid-argument", "يرجى كتابة رمز التحقق المكون من 6 أرقام بشكل صحيح");
  }

  const cleanEmail = email.trim().lowercase();
  const emailHash = hashEmail(cleanEmail);
  const otpRef = db.collection("otp_codes").doc(emailHash);
  const docSnapshot = await otpRef.get();

  if (!docSnapshot.exists) {
    throw new HttpsError("not-found", "لم يتم العثور على طلب رمز تحقق لهذا البريد، يرجى طلب رمز جديد");
  }

  const data = docSnapshot.data();

  if (data.used) {
    throw new HttpsError("failed-precondition", "تم استخدام هذا الرمز من قبل، يرجى طلب رمز جديد");
  }

  const now = Date.now();
  if (data.expiresAt && data.expiresAt.toMillis() < now) {
    throw new HttpsError("deadline-exceeded", "انتهت صلاحية رمز التحقق (10 دقائق)، يرجى طلب رمز جديد");
  }

  // Brute force protection (max 5 incorrect attempts)
  if (data.attempts >= 5) {
    await otpRef.update({ used: true });
    throw new HttpsError(
      "permission-denied",
      "تجاوزت الحد المسموح من المحاولات الخاطئة (5 محاولات)، تم إلغاء الرمز. يرجى طلب رمز جديد"
    );
  }

  const inputHash = hashOtp(otpCode);
  if (data.codeHash !== inputHash) {
    await otpRef.update({ attempts: admin.firestore.FieldValue.increment(1) });
    throw new HttpsError("invalid-argument", "رمز التحقق غير صحيح، يرجى إعادة التأكد والتجربة مرة أخرى");
  }

  // Mark OTP as used
  await otpRef.update({ used: true, verifiedAt: admin.firestore.Timestamp.fromMillis(now) });

  return {
    success: true,
    verified: true,
    message: "تم توثيق البريد الإلكتروني بنجاح"
  };
});
